document.write(	
	'<script type="text/javascript" src="js/jquery.min.js"></script>' +	
	'<script type="text/javascript" src="js/general.js"></script>'
);